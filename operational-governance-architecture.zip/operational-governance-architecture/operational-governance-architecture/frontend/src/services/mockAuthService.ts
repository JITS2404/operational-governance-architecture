import { User, LoginCredentials, UserRole } from '@/types/auth';

// Mock users for development/demo
const mockUsers: (User & { password: string })[] = [
  {
    id: '1',
    email: 'admin@maintenance.com',
    password: 'admin123',
    firstName: 'Admin',
    lastName: 'User',
    role: UserRole.PLATFORM_ADMIN,
    avatar: '',
    phone: '+1 (555) 123-4567',
    organizationId: 'org-1',
    isActive: true,
    createdAt: '2024-01-01T00:00:00Z',
    updatedAt: '2024-01-15T00:00:00Z'
  },
  {
    id: '2',
    email: 'manager@maintenance.com',
    password: 'manager123',
    firstName: 'Sarah',
    lastName: 'Johnson',
    role: UserRole.MAINTENANCE_TEAM,
    avatar: '',
    phone: '+1 (555) 234-5678',
    organizationId: 'org-1',
    isActive: true,
    createdAt: '2024-01-01T00:00:00Z',
    updatedAt: '2024-01-15T00:00:00Z'
  },
  {
    id: '3',
    email: 'tech@maintenance.com',
    password: 'tech123',
    firstName: 'Mike',
    lastName: 'Smith',
    role: UserRole.TECHNICIAN,
    avatar: '',
    phone: '+1 (555) 345-6789',
    organizationId: 'org-1',
    isActive: true,
    createdAt: '2024-01-01T00:00:00Z',
    updatedAt: '2024-01-15T00:00:00Z'
  },
  {
    id: '4',
    email: 'supervisor@maintenance.com',
    password: 'super123',
    firstName: 'Emily',
    lastName: 'Davis',
    role: UserRole.HEAD,
    avatar: '',
    phone: '+1 (555) 456-7890',
    organizationId: 'org-1',
    isActive: true,
    createdAt: '2024-01-01T00:00:00Z',
    updatedAt: '2024-01-15T00:00:00Z'
  },
  {
    id: '5',
    email: 'reporter@maintenance.com',
    password: 'reporter123',
    firstName: 'John',
    lastName: 'Reporter',
    role: UserRole.REPORTER,
    avatar: '',
    phone: '+1 (555) 567-8901',
    organizationId: 'org-1',
    isActive: true,
    createdAt: '2024-01-01T00:00:00Z',
    updatedAt: '2024-01-15T00:00:00Z'
  },
  {
    id: '6',
    email: 'finance@maintenance.com',
    password: 'finance123',
    firstName: 'Lisa',
    lastName: 'Finance',
    role: UserRole.FINANCE_TEAM,
    avatar: '',
    phone: '+1 (555) 678-9012',
    organizationId: 'org-1',
    isActive: true,
    createdAt: '2024-01-01T00:00:00Z',
    updatedAt: '2024-01-15T00:00:00Z'
  }
];

const generateToken = (user: User): string => {
  return btoa(JSON.stringify({ 
    userId: user.id, 
    email: user.email, 
    role: user.role,
    exp: Date.now() + (24 * 60 * 60 * 1000)
  }));
};

const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

export const mockAuthService = {
  async login(credentials: LoginCredentials): Promise<{ user: User; token: string }> {
    await delay(1000);

    const mockUser = mockUsers.find(
      u => u.email === credentials.email && u.password === credentials.password
    );

    if (!mockUser) {
      throw new Error('Invalid email or password');
    }

    if (!mockUser.isActive) {
      throw new Error('Account is deactivated');
    }

    const { password, ...user } = mockUser;
    const token = generateToken(user);

    return { user, token };
  },

  async getCurrentUser(token: string): Promise<User> {
    await delay(500);

    try {
      const decoded = JSON.parse(atob(token));
      
      if (decoded.exp < Date.now()) {
        throw new Error('Token expired');
      }

      const mockUser = mockUsers.find(u => u.id === decoded.userId);
      
      if (!mockUser || !mockUser.isActive) {
        throw new Error('User not found or inactive');
      }

      const { password, ...user } = mockUser;
      return user;
    } catch (error) {
      throw new Error('Invalid token');
    }
  },

  async updateProfile(data: Partial<User>): Promise<User> {
    await delay(800);

    const currentUser = mockUsers.find(u => u.id === data.id);
    if (!currentUser) {
      throw new Error('User not found');
    }

    const updatedUser = { ...currentUser, ...data, updatedAt: new Date().toISOString() };
    const { password, ...user } = updatedUser;
    
    return user;
  }
};

export { mockUsers };