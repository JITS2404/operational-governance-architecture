const express = require('express');
const { Pool } = require('pg');
const cors = require('cors');
require('dotenv').config();

const app = express();
const port = process.env.PORT || 3002;

// PostgreSQL connection
const pool = new Pool({
  user: process.env.DB_USER || 'postgres',
  host: process.env.DB_HOST || 'localhost',
  database: process.env.DB_NAME || 'maintenance_db',
  password: process.env.DB_PASSWORD,
  port: process.env.DB_PORT || ,
});

// Test database connection
pool.connect((err, client, release) => {
  if (err) {
    console.error('Database connection error:', err.stack);
  } else {
    console.log('Connected to PostgreSQL database');
    release();
  }
});

app.use(cors());
app.use(express.json());

// Enable authentication service to use real API
const USE_MOCK_API = false;

// Auth endpoints
app.post('/api/auth/login', async (req, res) => {
  try {
    console.log('Login attempt for:', req.body.email);
    const { email, password } = req.body;
    const result = await pool.query(
      'SELECT * FROM users WHERE email = $1 AND password_hash = $2 AND is_active = true',
      [email, password]
    );
    
    console.log('Query result:', result.rows.length, 'users found');
    
    if (result.rows.length === 0) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }
    
    const user = result.rows[0];
    res.json({ user, token: `token_${user.id}_${Date.now()}` });
  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({ error: error.message });
  }
});

// Users endpoints
app.get('/api/users', async (req, res) => {
  try {
    console.log('Fetching users from database...');
    const result = await pool.query('SELECT * FROM users WHERE is_active = true ORDER BY first_name');
    console.log('Users found:', result.rows.length);
    res.json(result.rows);
  } catch (error) {
    console.error('Users endpoint error:', error);
    res.status(500).json({ error: error.message });
  }
});

// Create user
app.post('/api/users', async (req, res) => {
  try {
    const { email, password_hash, first_name, last_name, role, phone, is_active } = req.body;
    
    if (!email || !password_hash || !first_name || !last_name || !role) {
      return res.status(400).json({ 
        error: 'Missing required fields',
        required: ['email', 'password_hash', 'first_name', 'last_name', 'role']
      });
    }
    
    const result = await pool.query(
      'INSERT INTO users (email, password_hash, first_name, last_name, role, phone, is_active) VALUES ($1, $2, $3, $4, $5, $6, $7) RETURNING *',
      [email, password_hash, first_name, last_name, role, phone || null, is_active !== false]
    );
    
    res.json(result.rows[0]);
  } catch (error) {
    console.error('User creation error:', error);
    if (error.code === '23505') {
      return res.status(409).json({ error: 'User with this email already exists' });
    }
    res.status(500).json({ error: error.message });
  }
});

// Categories endpoints
app.get('/api/categories', async (req, res) => {
  try {
    const result = await pool.query('SELECT * FROM categories WHERE is_active = true ORDER BY name');
    res.json(result.rows);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Locations endpoints
app.get('/api/locations', async (req, res) => {
  try {
    const result = await pool.query('SELECT * FROM locations WHERE is_active = true ORDER BY name');
    res.json(result.rows);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Tickets endpoints
app.get('/api/tickets', async (req, res) => {
  try {
    const { reporter_id, assigned_technician_id, status } = req.query;
    
    let query = `
      SELECT t.*, 
             u.first_name || ' ' || u.last_name as reporter_name,
             c.name as category_name,
             l.name as location_name
      FROM tickets t
      LEFT JOIN users u ON t.reporter_id = u.id
      LEFT JOIN categories c ON t.category_id = c.id
      LEFT JOIN locations l ON t.location_id = l.id
    `;
    
    const conditions = [];
    const values = [];
    
    if (reporter_id) {
      conditions.push(`t.reporter_id = $${values.length + 1}`);
      values.push(reporter_id);
    }
    
    if (assigned_technician_id) {
      conditions.push(`t.assigned_technician_id = $${values.length + 1}`);
      values.push(assigned_technician_id);
    }
    
    if (status) {
      conditions.push(`t.status = $${values.length + 1}`);
      values.push(status);
    }
    
    if (conditions.length > 0) {
      query += ' WHERE ' + conditions.join(' AND ');
    }
    
    query += ' ORDER BY t.created_at DESC';
    
    const result = await pool.query(query, values);
    res.json(result.rows);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get single ticket by ID
app.get('/api/tickets/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const result = await pool.query(`
      SELECT t.*, 
             u.first_name || ' ' || u.last_name as reporter_name,
             c.name as category_name,
             l.name as location_name
      FROM tickets t
      LEFT JOIN users u ON t.reporter_id = u.id
      LEFT JOIN categories c ON t.category_id = c.id
      LEFT JOIN locations l ON t.location_id = l.id
      WHERE t.id = $1
    `, [id]);
    
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Ticket not found' });
    }
    
    res.json(result.rows[0]);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.post('/api/tickets', async (req, res) => {
  try {
    console.log('Creating ticket with data:', req.body);
    const { title, description, priority, category_id, location_id, floor_no, room_no, reporter_id } = req.body;
    
    // Validate required fields
    if (!title || !description || !category_id || !location_id || !reporter_id) {
      return res.status(400).json({ 
        error: 'Missing required fields', 
        required: ['title', 'description', 'category_id', 'location_id', 'reporter_id'],
        received: { title, description, category_id, location_id, reporter_id }
      });
    }
    
    // Generate ticket number
    const ticketNumber = `TKT-${Date.now()}-${Math.floor(Math.random() * 1000).toString().padStart(3, '0')}`;
    
    const result = await pool.query(`
      INSERT INTO tickets (ticket_number, title, description, priority, category_id, location_id, reporter_id, floor_no, room_no, status)
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, 'NEW')
      RETURNING *
    `, [ticketNumber, title, description, priority || 'MEDIUM', category_id, location_id, reporter_id, floor_no, room_no]);
    
    console.log('Ticket created successfully:', result.rows[0]);
    res.json(result.rows[0]);
  } catch (error) {
    console.error('Ticket creation error:', error);
    console.error('Error details:', {
      message: error.message,
      code: error.code,
      detail: error.detail,
      hint: error.hint
    });
    res.status(500).json({ 
      error: error.message,
      code: error.code,
      detail: error.detail,
      hint: error.hint
    });
  }
});

app.put('/api/tickets/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const { title, description, priority, category_id, location_id, floor_no, room_no } = req.body;
    
    const result = await pool.query(`
      UPDATE tickets 
      SET title = $1, description = $2, priority = $3, category_id = $4, location_id = $5, floor_no = $6, room_no = $7, updated_at = NOW()
      WHERE id = $8
      RETURNING *
    `, [title, description, priority, category_id, location_id, floor_no, room_no, id]);
    
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Ticket not found' });
    }
    
    res.json(result.rows[0]);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Update ticket status
app.put('/api/tickets/:id/status', async (req, res) => {
  try {
    const { id } = req.params;
    const { status, updated_by, notes } = req.body;
    
    const result = await pool.query(`
      UPDATE tickets 
      SET status = $1, updated_at = NOW()
      WHERE id = $2
      RETURNING *
    `, [status, id]);
    
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Ticket not found' });
    }
    
    res.json(result.rows[0]);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Assign technician
app.put('/api/tickets/:id/assign', async (req, res) => {
  try {
    const { id } = req.params;
    const { technician_id, assigned_by } = req.body;
    
    const result = await pool.query(`
      UPDATE tickets 
      SET assigned_technician_id = $1, assigned_by = $2, assigned_at = NOW(), status = 'ASSIGNED_TO_TECHNICIAN', updated_at = NOW()
      WHERE id = $3
      RETURNING *
    `, [technician_id, assigned_by, id]);
    
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Ticket not found' });
    }
    
    res.json(result.rows[0]);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Delete ticket
app.delete('/api/tickets/:id', async (req, res) => {
  try {
    const { id } = req.params;
    
    const result = await pool.query('DELETE FROM tickets WHERE id = $1 RETURNING *', [id]);
    
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Ticket not found' });
    }
    
    res.json({ message: 'Ticket deleted successfully' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Categories CRUD
app.post('/api/categories', async (req, res) => {
  try {
    const { name, description } = req.body;
    const result = await pool.query(
      'INSERT INTO categories (name, description) VALUES ($1, $2) RETURNING *',
      [name, description || '']
    );
    res.json(result.rows[0]);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.put('/api/categories/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const { name, description } = req.body;
    const result = await pool.query(
      'UPDATE categories SET name = $1, description = $2, updated_at = NOW() WHERE id = $3 RETURNING *',
      [name, description, id]
    );
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Category not found' });
    }
    res.json(result.rows[0]);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.delete('/api/categories/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const result = await pool.query('DELETE FROM categories WHERE id = $1 RETURNING *', [id]);
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Category not found' });
    }
    res.json({ message: 'Category deleted successfully' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Locations CRUD
app.post('/api/locations', async (req, res) => {
  try {
    const { name, description, address } = req.body;
    const result = await pool.query(
      'INSERT INTO locations (name, description, address) VALUES ($1, $2, $3) RETURNING *',
      [name, description || '', address || '']
    );
    res.json(result.rows[0]);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.put('/api/locations/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const { name, description, address } = req.body;
    const result = await pool.query(
      'UPDATE locations SET name = $1, description = $2, address = $3, updated_at = NOW() WHERE id = $4 RETURNING *',
      [name, description, address, id]
    );
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Location not found' });
    }
    res.json(result.rows[0]);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.delete('/api/locations/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const result = await pool.query('DELETE FROM locations WHERE id = $1 RETURNING *', [id]);
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Location not found' });
    }
    res.json({ message: 'Location deleted successfully' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Update user
app.put('/api/users/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const { email, password_hash, first_name, last_name, is_active } = req.body;
    
    let query = 'UPDATE users SET ';
    const values = [];
    const updates = [];
    
    if (email) {
      updates.push(`email = $${values.length + 1}`);
      values.push(email);
    }
    if (password_hash) {
      updates.push(`password_hash = $${values.length + 1}`);
      values.push(password_hash);
    }
    if (first_name) {
      updates.push(`first_name = $${values.length + 1}`);
      values.push(first_name);
    }
    if (last_name) {
      updates.push(`last_name = $${values.length + 1}`);
      values.push(last_name);
    }
    if (typeof is_active === 'boolean') {
      updates.push(`is_active = $${values.length + 1}`);
      values.push(is_active);
    }
    
    if (updates.length === 0) {
      return res.status(400).json({ error: 'No fields to update' });
    }
    
    query += updates.join(', ') + ` WHERE id = $${values.length + 1} RETURNING *`;
    values.push(id);
    
    const result = await pool.query(query, values);
    
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'User not found' });
    }
    
    res.json(result.rows[0]);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Delete user
app.delete('/api/users/:id', async (req, res) => {
  try {
    const { id } = req.params;
    
    const result = await pool.query('DELETE FROM users WHERE id = $1 RETURNING *', [id]);
    
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'User not found' });
    }
    
    res.json({ message: 'User deleted successfully' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.listen(port, () => {
  console.log(`Backend server running on http://localhost:${port}`);
});