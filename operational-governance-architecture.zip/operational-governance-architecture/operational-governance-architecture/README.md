# MaintenanceHub - Professional Ticketing System

A comprehensive maintenance ticketing system built with React, TypeScript, and modern UI components. Features role-based access control, real-time notifications, and beautiful dashboard interfaces.

## 🎨 Design & Features

- **Mystic Plum Theme**: Professional color scheme with gradients and glass morphism effects
- **Role-Based Access Control**: 7 distinct user roles with appropriate permissions
- **Real-Time Notifications**: Mock WebSocket integration for live updates
- **Responsive Design**: Works seamlessly on desktop, tablet, and mobile
- **Modern UI Components**: Built with shadcn/ui and Tailwind CSS
- **Professional Dashboard**: Role-specific dashboards with charts and analytics

## 🚀 User Roles

### Platform Admin
- **Access**: Full system administration
- **Credentials**: `admin@maintenance.com` / `admin123`

### Maintenance Manager
- **Access**: Manage tickets, assign technicians, view dashboards
- **Credentials**: `manager@maintenance.com` / `manager123`

### Supervisor
- **Access**: Approve closures, manage categories, view reports
- **Credentials**: `supervisor@maintenance.com` / `super123`

### Technician
- **Access**: View assigned tickets, update status, add comments
- **Credentials**: `tech@maintenance.com` / `tech123`

### Finance Officer
- **Access**: View reports, export billing data
- **Credentials**: `finance@maintenance.com` / `finance123`

### Reporter (User)
- **Access**: Submit tickets, view own tickets, track status
- **Credentials**: `user@maintenance.com` / `user123`

### Client
- **Access**: Organization-level ticket visibility
- **Credentials**: `client@maintenance.com` / `client123`

## 🛠️ Tech Stack

- **React 18** with TypeScript
- **Tailwind CSS** for styling
- **shadcn/ui** components
- **React Router** for navigation
- **TanStack Query** for state management
- **Socket.IO Client** for real-time features
- **Axios** for API communication
- **React Hook Form** for forms
- **Recharts** for data visualization

## 📦 Installation

```bash
# Install dependencies
npm install

# Start development server
npm run dev
```

## 🎯 Key Features

### Authentication & Security
- JWT-based authentication
- Role-based route protection
- Secure password handling
- Session management

### Dashboard & Analytics
- Role-specific dashboard views
- Interactive charts and graphs
- Performance metrics
- Activity feeds

### Ticket Management
- Create, assign, and track tickets
- Status workflow enforcement
- File attachments support
- Comment system

### Real-Time Features
- Live notifications
- Status updates
- Assignment alerts
- Comment notifications

### Responsive Design
- Mobile-first approach
- Tablet optimization
- Desktop layouts
- Touch-friendly interfaces

## 🔧 Configuration

### Environment Variables
```env
NODE_ENV=development
REACT_APP_API_URL=http://localhost:3001/api
REACT_APP_WS_URL=ws://localhost:3001
```

### Mock vs Real API
The system currently uses mock services for development. To connect to real APIs:

1. Set `USE_MOCK_API = false` in `src/services/authService.ts`
2. Configure your backend API endpoints
3. Update service files with real implementations

## 🎨 Design System

The application uses a comprehensive design system with:

- **Primary Colors**: Mystic Plum (#87488f) with variations
- **Glass Morphism**: Backdrop blur effects and transparency
- **Semantic Tokens**: Consistent color usage throughout
- **Animation**: Smooth transitions and micro-interactions
- **Typography**: Professional font hierarchy

## 📱 Pages & Routes

- `/login` - Authentication page
- `/dashboard` - Role-specific dashboard
- `/tickets` - All tickets view (role-based)
- `/my-tickets` - Personal tickets
- `/tickets/new` - Create new ticket
- `/tickets/:id` - Ticket details
- `/reports` - Analytics and reports
- `/admin/*` - Administration pages
- `/profile` - User profile management

## 🚧 Backend Integration

To connect with a real backend:

1. **Authentication API**: Implement JWT-based auth endpoints
2. **Ticket Management**: CRUD operations for tickets
3. **User Management**: Role and permission management
4. **File Upload**: Handle attachment uploads
5. **WebSocket**: Real-time notification system
6. **Reporting**: Analytics and export functionality

### Required API Endpoints

```
POST /api/auth/login
GET  /api/auth/me
PUT  /api/auth/profile
POST /api/auth/change-password

GET    /api/tickets
POST   /api/tickets
GET    /api/tickets/:id
PUT    /api/tickets/:id
DELETE /api/tickets/:id

GET  /api/users
POST /api/users
PUT  /api/users/:id

GET /api/reports/dashboard
GET /api/reports/export
```

## 📄 License

This project is built for demonstration purposes. Please ensure you have the necessary licenses for production use.

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## 📞 Support

For questions or issues, please contact the development team or create an issue in the repository.

---

**MaintenanceHub** - Streamline your maintenance operations with professional ticketing management.